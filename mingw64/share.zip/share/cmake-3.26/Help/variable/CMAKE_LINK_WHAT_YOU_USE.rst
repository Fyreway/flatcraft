CMAKE_LINK_WHAT_YOU_USE
-----------------------

.. versionadded:: 3.7

Default value for :prop_tgt:`LINK_WHAT_YOU_USE` target property.
This variable is used to initialize the property on each target as it is
created.
