CTEST_HG_COMMAND
----------------

.. versionadded:: 3.1

Specify the CTest ``HGCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
