CMAKE_VS_SDK_LIBRARY_DIRECTORIES
--------------------------------

.. versionadded:: 3.12

This variable allows to override Visual Studio default Library Directories.
