CTEST_CUSTOM_ERROR_MATCH
------------------------

A list of regular expressions which will be used to detect error messages in
build outputs by the :command:`ctest_build` command.

.. include:: CTEST_CUSTOM_XXX.txt
