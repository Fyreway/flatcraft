CTEST_CUSTOM_TESTS_IGNORE
-------------------------

A list of test names to be excluded from the set of tests run by the
:command:`ctest_test` command.

.. include:: CTEST_CUSTOM_XXX.txt
