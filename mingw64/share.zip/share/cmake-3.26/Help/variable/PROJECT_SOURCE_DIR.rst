PROJECT_SOURCE_DIR
------------------

This is the source directory of the last call to the
:command:`project` command made in the current directory scope or one
of its parents. Note, it is not affected by calls to
:command:`project` made within a child directory scope (i.e. from
within a call to :command:`add_subdirectory` from the current scope).
