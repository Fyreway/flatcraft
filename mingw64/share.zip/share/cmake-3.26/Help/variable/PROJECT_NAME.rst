PROJECT_NAME
------------

Name of the project given to the project command.

This is the name given to the most recently called :command:`project`
command in the current directory scope or above.  To obtain the name of
the top level project, see the :variable:`CMAKE_PROJECT_NAME` variable.
