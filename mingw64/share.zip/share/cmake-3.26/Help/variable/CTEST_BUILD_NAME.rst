CTEST_BUILD_NAME
----------------

.. versionadded:: 3.1

Specify the CTest ``BuildName`` setting
in a :manual:`ctest(1)` dashboard client script.
