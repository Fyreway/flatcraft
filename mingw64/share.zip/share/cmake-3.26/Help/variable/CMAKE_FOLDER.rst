CMAKE_FOLDER
------------

.. versionadded:: 3.12

Set the folder name. Use to organize targets in an IDE.

This variable is used to initialize the :prop_tgt:`FOLDER` property on all the
targets.  See that target property for additional information.
