CTEST_UPDATE_VERSION_OVERRIDE
-----------------------------

.. versionadded:: 3.15

Specify the CTest :ref:`UpdateVersionOverride <UpdateVersionOverride>` setting
in a :manual:`ctest(1)` dashboard client script.
